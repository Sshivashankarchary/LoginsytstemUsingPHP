   <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; <?php echo date('Y');?></div>
                            <div>
                                <a href="dashboard.php" target="_blank">Go back to dashboard</a>
    
                            </div>
                        </div>
                    </div>
                </footer>
            </div>